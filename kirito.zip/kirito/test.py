with open("king.txt", "w") as f:
	f.write(test)
